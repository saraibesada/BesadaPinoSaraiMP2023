package org.mp.sesion02;

public interface DeColor {

	public abstract String comoColorear();
	
}
