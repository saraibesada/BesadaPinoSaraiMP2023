package org.mp.sesion02;

public class ExcepcionArrayVacio extends Exception {

	public ExcepcionArrayVacio(String msg) {
		super(msg);
	}
	
}
